import { 
  MODULE_ID, 
  DEFAULT_MAX_CONVERSION_LEVEL, 
  ACTOR_FLAG, 
  GLOBAL_SETTING,
} from "../utilities/constants.js";

import { 
  openConversionDialog, 
  openActorConfigDialog, 
  openActorColorConfig 
} from "./dialogs.js";

import { getActorSetting } from "../utilities/helpers.js";
import { getRemainingConversions } from "../logic/cantrip-state.js";

import {
  isConversionEnabled,
  getMaxConversionsPerLongRest,
  getCostPerLevel,
} from "../logic/conversions.js";



/* ============================================ */
/*  Apply Cantrip Logic                         */
/* ============================================ */

export async function applyCantripLogic(app, root, primaryResource) {
  const actor = app.actor;
  if (!primaryResource || !actor) return;

  const figure = primaryResource.querySelector("figure");
  if (!figure) return;

  let icon = figure.querySelector("img");
  if (!icon) return;

  const isEditMode = !!root.querySelector("input.document-name") || app.isEditable === true;
  const conversionEnabled = isConversionEnabled(actor);

  /* ---------- Restrict Manual Editing ---------- */
  const valueInput = primaryResource.querySelector('input.uninput.value, input[name$=".value"]');
  if (valueInput) {
    if (!game.user.isGM) {
      valueInput.disabled = true;
      valueInput.style.pointerEvents = "none";
      valueInput.style.opacity = "0.7";
      valueInput.title = "Only the GM may manually adjust cantrip uses.";
    } else {
      valueInput.disabled = false;
      valueInput.style.pointerEvents = "";
      valueInput.style.opacity = "";
      valueInput.title = "";
    }
  }

  /* ---------- Replace Icon (Robust) ---------- */
  const customIcon = (game.settings.get(MODULE_ID, "cantripIcon") || "").trim();
  const defaultIcon = `modules/${MODULE_ID}/assets/cantrips.png`;
  const newIconSrc = customIcon || defaultIcon;

  // Force update the icon src
  if (icon.src !== newIconSrc) {
    icon.src = newIconSrc;
    icon.dataset.originalSrc = newIconSrc;   // mark it so we can detect later if needed
  }

  // Extra safety for V2 sheet (some styles use background on figure or img)
  figure.style.backgroundImage = `url("${newIconSrc}")`;
  icon.style.backgroundImage = `url("${newIconSrc}")`;   // added extra fallback

  /* ---------- Icon Interaction ---------- */
  // Clear any previous handlers to prevent duplicates
  const newClickHandler = (event) => {
    if (!conversionEnabled || isEditMode) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    openConversionDialog(actor);
  };

  icon.style.cursor = isEditMode || !conversionEnabled ? "default" : "pointer";
  icon.title = isEditMode 
    ? "Cantrip Uses (Locked in Edit Mode)" 
    : conversionEnabled 
      ? "Convert Cantrips to Spell Slots" 
      : "Cantrip Uses";

  // Replace the click handler cleanly
  icon.removeEventListener("click", newClickHandler);   // remove old version if exists
  if (!isEditMode && conversionEnabled) {
    icon.addEventListener("click", newClickHandler);
  } else {
    icon.onclick = null;   // safety
  }

  /* ---------- Delete Favorite Handling ---------- */
  const deleteButton = primaryResource.querySelector('button[data-action="deleteFavorite"]');
  if (deleteButton) {
    if (isEditMode) {
      deleteButton.disabled = true;
      deleteButton.style.pointerEvents = "none";
      deleteButton.style.opacity = "0.4";
    } else {
      deleteButton.disabled = false;
      deleteButton.style.pointerEvents = "";
      deleteButton.style.opacity = "";
    }
  }

  /* ---------- GM Config Gear ---------- */
  if (game.user.isGM && isEditMode) {
    const headerButtons = root.querySelector(".sheet-header-buttons");
    if (headerButtons && !headerButtons.querySelector(".cantrip-config-gear")) {
      const gear = document.createElement("button");
      gear.type = "button";
      gear.classList.add("gold-button", "cantrip-config-gear");
      gear.innerHTML = `<i class="fas fa-cog"></i>`;
      gear.title = "Cantrip Conversion Settings";
      gear.style.marginLeft = "4px";

      gear.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        openActorConfigDialog(actor);
      });

      headerButtons.appendChild(gear);
    }
  }

  /* ---------- Player Color Config ---------- */
  let existingColorIcon = primaryResource.querySelector(".cantrip-color-config");
  if (existingColorIcon) existingColorIcon.remove();

  if (isEditMode) {
    const colorIcon = document.createElement("button");
    colorIcon.type = "button";
    colorIcon.classList.add("gold-button", "cantrip-color-config");
    colorIcon.innerHTML = `<i class="fas fa-palette"></i>`;
    colorIcon.title = "Configure Cantrip Resource Colors";
    colorIcon.style.marginLeft = "4px";

    colorIcon.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      openActorColorConfig(actor);
    });

    primaryResource.appendChild(colorIcon);
  }

  /* ---------- Color + Glow ---------- */
  const color = updateCantripResourceColor(root, actor);
  updateConversionGlow(root, actor, color);
  updateGearGlow(root, actor, color);
}

/* ============================================ */
/*  Color Logic                                 */
/* ============================================ */

function updateCantripResourceColor(html, actor) {

  const resource = actor?.system?.resources?.secondary;
  if (!resource) return null;

  const value = resource.value ?? 0;
  const max = resource.max ?? 1;
  const percent = max > 0 ? (value / max) * 100 : 0;

  const valueInput = html.querySelector(
    'li.resource[data-favorite-id="resources.secondary"] input.uninput.value'
  );

  if (!valueInput) return null;

  const glowLow = getActorSetting(actor, ACTOR_FLAG.glowLow, GLOBAL_SETTING.glowLow);
  const glowMedium = getActorSetting(actor, ACTOR_FLAG.glowMedium, GLOBAL_SETTING.glowMedium);
  const glowHigh = getActorSetting(actor, ACTOR_FLAG.glowHigh, GLOBAL_SETTING.glowHigh);

  let thresholdLow = Number(getActorSetting(actor, ACTOR_FLAG.thresholdLow, GLOBAL_SETTING.thresholdLow));
  let thresholdMedium = Number(getActorSetting(actor, ACTOR_FLAG.thresholdMedium, GLOBAL_SETTING.thresholdMedium));

  if (!Number.isFinite(thresholdLow) ||
      !Number.isFinite(thresholdMedium) ||
      thresholdLow >= thresholdMedium) {
    thresholdLow = 25;
    thresholdMedium = 50;
  }

  let color;

  if (percent <= thresholdLow) color = glowLow;
  else if (percent <= thresholdMedium) color = glowMedium;
  else color = glowHigh;

  valueInput.style.setProperty("color", color, "important");

  return color;
}

/* ============================================ */
/*  Conversion Glow                             */
/* ============================================ */

function updateConversionGlow(html, actor, glowColor) {

  if (!isConversionEnabled(actor)) return;

  const resourceRow = html.querySelector(
    'li.resource[data-favorite-id="resources.secondary"]'
  );
  if (!resourceRow) return;

  const maxConversions = getMaxConversionsPerLongRest(actor);
  const conversionsRemaining = getRemainingConversions(actor);

  if (maxConversions > 0 && conversionsRemaining <= 0) {
    resourceRow.style.boxShadow = "";
    return;
  }

  const remaining = actor.system.resources.secondary?.value ?? 0;
  const spellData = actor.system.spells;
  const costPerLevel = getCostPerLevel(actor);

  let maxLevel = getActorSetting(actor, ACTOR_FLAG.maxConversionLevel, GLOBAL_SETTING.maxConversionLevel);

  if (!Number.isInteger(maxLevel) || maxLevel <= 0)
    maxLevel = DEFAULT_MAX_CONVERSION_LEVEL;

  let canConvert = false;

  for (let level = 1; level <= maxLevel; level++) {

    const slot = spellData?.[`spell${level}`];
    if (!slot) continue;

    const cost = level * costPerLevel;

    if (slot.value < slot.max && remaining >= cost) {
      canConvert = true;
      break;
    }
  }

  if (canConvert && glowColor) {

    const r = parseInt(glowColor.slice(1, 3), 16);
    const g = parseInt(glowColor.slice(3, 5), 16);
    const b = parseInt(glowColor.slice(5, 7), 16);

    resourceRow.style.boxShadow =
      `0 0 8px 2px rgba(${r}, ${g}, ${b}, 0.8)`;

  } else {
    resourceRow.style.boxShadow = "";
  }
}

/* ============================================ */
/*  Gear Glow                                   */
/* ============================================ */

function updateGearGlow(html, actor, glowColor) {

  const gear = html.querySelector(".cantrip-config-gear");
  if (!gear) return;

  if (!isConversionEnabled(actor)) {
    gear.style.boxShadow = "";
    return;
  }

  const resource = actor.system.resources?.secondary;
  if (!resource) return;

  const current = resource.value ?? 0;
  const costPerLevel = getCostPerLevel(actor);
  const minCost = costPerLevel;

  const maxConversions = getMaxConversionsPerLongRest(actor);
  const conversionsRemaining = getRemainingConversions(actor);

  const conversionBlocked =
    current < minCost ||
    (maxConversions > 0 && conversionsRemaining <= 0);

  if (conversionBlocked) {
    gear.style.boxShadow = "";
    return;
  }

  gear.style.boxShadow = `0 0 6px 2px ${glowColor}`;
}