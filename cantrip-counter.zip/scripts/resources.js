import { getSpellcastingAbilityScore } from "./helpers.js";
import { resetConversionsUsed } from "./helpers.js";
import { debugLog } from "./debug.js";

/* -------------------------------------------- */
/*  SYNC RESOURCE                               */
/* -------------------------------------------- */

export async function syncResource(actor) {

  if (!actor || actor.type !== "character") return;

  const abilityScore = getSpellcastingAbilityScore(actor);
  if (!abilityScore) return;

  const resource = actor.system.resources?.primary;
  const updates = {};

  if (!resource) {
    updates["system.resources.primary"] = {
      label: "Cantrip Uses",
      value: abilityScore,
      max: abilityScore,
      sr: true,
      lr: true
    };
  } else {

    if (resource.label !== "Cantrip Uses")
      updates["system.resources.primary.label"] = "Cantrip Uses";

    if (resource.max !== abilityScore)
      updates["system.resources.primary.max"] = abilityScore;

    if (resource.value == null)
      updates["system.resources.primary.value"] = abilityScore;
  }

  if (Object.keys(updates).length > 0)
    await actor.update(updates);
}

/* -------------------------------------------- */
/*  ABILITY SCORE CHANGE                        */
/* -------------------------------------------- */

Hooks.on("updateActor", async (actor, changes) => {

  if (!actor.hasPlayerOwner) return;
  if (actor.type !== "character") return;

  const abilityKey = actor.system.attributes.spellcasting;
  if (!abilityKey) return;

  const abilityChanges = changes?.system?.abilities?.[abilityKey];
  if (!abilityChanges || abilityChanges.value === undefined) return;

  debugLog(`${actor.name}'s spellcasting ability changed.`);
  await refreshSingleActorMaximum(actor);

});

/* -------------------------------------------- */
/*  REST COMPLETED                              */
/* -------------------------------------------- */

Hooks.on("dnd5e.restCompleted", async (actor) => {

  if (!actor || actor.type !== "character") return;

  await syncResource(actor);

  const abilityScore = getSpellcastingAbilityScore(actor);
  if (!abilityScore) return;

  await actor.update({
    "system.resources.primary.max": abilityScore,
    "system.resources.primary.value": abilityScore
  });

  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<p><strong>${actor.name}</strong>'s Cantrip Uses have been fully restored.<br>Total Available: ${abilityScore}</p>`,
    style: CONST.CHAT_MESSAGE_STYLES.OTHER
  });

  if (actor.sheet?.rendered) actor.sheet.render(true);
});

/* -------------------------------------------- */
/*  LONG REST                                   */
/* -------------------------------------------- */

Hooks.on("dnd5e.longRest", async (actor) => {

  if (!actor || actor.type !== "character") return;

  await syncResource(actor);

  const abilityScore = getSpellcastingAbilityScore(actor);
  if (!abilityScore) return;

  await actor.update({
    "system.resources.primary.max": abilityScore,
    "system.resources.primary.value": abilityScore
  });

  await resetConversionsUsed(actor);

  ChatMessage.create({
    speaker: ChatMessage.getSpeaker({ actor }),
    content: `<p><strong>${actor.name}</strong>'s Cantrip Uses restored.<br>Total Available: ${abilityScore}</p>`,
    style: CONST.CHAT_MESSAGE_STYLES.OTHER
  });

  if (actor.sheet?.rendered) actor.sheet.render(true);
});

/* -------------------------------------------- */
/*  MAX REFRESH                                 */
/* -------------------------------------------- */

export async function refreshSingleActorMaximum(actor) {

  const abilityScore = getSpellcastingAbilityScore(actor);
  if (!abilityScore) return;

  const resource = actor.system.resources.primary;
  if (!resource) return;

  const updates = {
    "system.resources.primary.max": abilityScore
  };

  if (resource.value > abilityScore)
    updates["system.resources.primary.value"] = abilityScore;

  await actor.update(updates);
}

export async function refreshAllCantripMaximums() {

  for (const actor of game.actors) {
    if (!actor.hasPlayerOwner) continue;
    if (actor.type !== "character") continue;
    await refreshSingleActorMaximum(actor);
  }
}

import { MODULE_ID } from "./settings.js";

/* -------------------------------------------- */
/*  BONUS CANTRIP SETTING CHANGE LISTENER       */
/* -------------------------------------------- */
Hooks.on("updateSetting", async (setting) => {

  if (setting.key !== `${MODULE_ID}.bonusCantrips`) return;

  await refreshAllCantripMaximums();
});
